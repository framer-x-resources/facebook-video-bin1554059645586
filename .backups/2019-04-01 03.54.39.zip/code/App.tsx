import { Data, animate, Override, Animatable } from 'framer'

const data = Data({ bgScale: Animatable(1), bgOpacity: Animatable(1) })

export const BG2: Override = () => {
  return {
    scale: data.bgScale,
    opacity: data.bgOpacity,
  }
}
