import { Data, animate, Override, Animatable } from 'framer'

const data = Data({
  bgScale: Animatable(1),
  bgOpacity: Animatable(1),
  popVideoTop: Animatable(0),
})

export const BG2: Override = () => {
  return {
    scale: data.bgScale,
    opacity: data.bgOpacity,
  }
}

export const PopVideo2: Override = () => {
  return {
    top: data.popVideoTop,
  }
}

var videoOrigin
export const Video2: Override = () => {
  return {
    onTap(event) {
      animate.ease(data.bgOpacity, 0)
      animate.ease(data.bgScale, 0.9)

      // PopVideo move!
      console.log('event', event)
      videoOrigin = event.devicePoint.y - event.point.y
      data.popVideoTop.set(videoOrigin)
      animate.ease(data.popVideoTop, 308)
    },
  }
}
