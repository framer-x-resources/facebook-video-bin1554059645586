import { Data, animate, Override, Animatable } from 'framer'

const data = Data({ bgScale: Animatable(1), bgOpacity: Animatable(1) })

export const BG1: Override = () => {
  return {
    scale: data.bgScale,
  }
}

export const Video1: Override = () => {
  return {
    onTap() {
      data.bgScale.set(0.6)
      animate.spring(data.bgScale, 1)
    },
  }
}
