import { Data, animate, Override, Animatable } from 'framer'

const data = Data({
  bgOpacity: Animatable(1),
  bgScale: Animatable(1),

  popVideoTop: Animatable(900),
  popVideoLeft: Animatable(12),
  popVideoWidth: Animatable(350),
  popVideoVisible: false,
})

export const sleep = sec => {
  return new Promise(resolve => setTimeout(resolve, sec * 1000))
}

var defaultEase = {
  duration: 0.3,
}

var videoOrigin
export const Video: Override = () => {
  return {
    async onTap(e) {
      console.log('open!')
      // visible Property 로 보이게 하기
      data.popVideoVisible = true

      // 애니매이션의 시작점 정하기 (Javascript Event 값을 이용. 리액트 X)
      videoOrigin = e.devicePoint.y - e.point.y
      data.popVideoTop.set(videoOrigin)

      // opacity Property 로 BG 작아지면서, 안보이게 하는 애니매이션
      animate.ease(data.bgOpacity, 0, defaultEase)
      animate.ease(data.bgScale, 0.9, defaultEase)

      // 비디오가 작을경우 왼쪽에 스케일
      // animate.ease(data.popVideoLeft, 0, defaultEase)
      animate.ease(data.popVideoWidth, 375, defaultEase)

      // 0.2 초를 쉽니다
      await sleep(0.2)

      // 비디오를 화면 중간에 놓기
      animate.easeInOut(data.popVideoTop, 308, defaultEase) // spring would be better
    },
  }
}

export const PopVideo: Override = () => {
  return {
    top: data.popVideoTop,
    visible: data.popVideoVisible,
    async onTap() {
      console.log('close!')
      animate.easeInOut(data.popVideoTop, videoOrigin, defaultEase) // spring would be better

      await sleep(0.2)

      animate.ease(data.bgOpacity, 1, defaultEase)
      animate.ease(data.bgScale, 1, defaultEase)

      // hide pop
      data.popVideoVisible = false
    },
  }
}

export const BG: Override = () => {
  return {
    scale: data.bgScale,
    opacity: data.bgOpacity,
  }
}
